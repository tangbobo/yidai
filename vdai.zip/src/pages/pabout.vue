<template>
    <ipage>
        <iheader slot="header" title="关于我们" />
        <div>
            <div class="cube-form_groups">
                <div class="ipdall ibgblue itxtcenter">
                    <i class="cubeic-safe-pay" style="font-size:40px"></i>
                    <div class="ipdt ipdb mini" style="font-size:12px">累计借出</div>
                    <div class="ipdb ifontbiger">1547000.00</div>
                </div>
            </div>
            <div class="ipdall itxtcenter">
                <div class="ipdt ipdb">容易贷</div>
                <div class="ipdt ipdb ifontlink">只需要一张身份证，就能借钱</div>
                <div class="ipdt ipdb">手机上的提款机</div>
                <div class="ipdt ipdb ifontlink">安全可靠</div>
                <div class="ipdt ipdb">随借随还</div>
                <div class="ipdall ifontxs">
                    © 2015 - 2018
                </div>
            </div>
        </div>
    </ipage>
</template>

<script>
    export default {}
</script>

<style>

</style>
