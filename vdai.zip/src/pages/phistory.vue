<template>
    <ipage>
        <iheader slot="header" title="借款记录" />
        <div class="ipdt">
            <div class="ipdb" v-for="a in 4">
                <div class="ibgwhite" @click="goStep">
                    <div class="cube-form_groups">
                        <div class="cube-form-group-legend">
                            <div class="iflex">
                                <div class="iflexitem"> 借款编号：H75454578985457</div>
                                <div>审核中</div>
                            </div>
                        </div>
                        <div class="ipdall iflex iflexcenter">
                            <div class="ipdr">
                                <div style="width:40px;height:40px;background:#EEE;"></div>
                            </div>
                            <div class="iflexitem">
                                <div class="ifontxs">借款金额：￥25000.00</div>
                                <div class="ifontxs ipdt mini">每月还款：￥2000.00 X 3期</div>
                            </div>
                            <i class="cubeic-arrow"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </ipage>
</template>

<script>
    export default {
        methods: {
            goStep() {
                this.$router.push("/account/apply/confirm/step/detail")
            }
        }
    }
</script>

<style>

</style>
