<template>
    <div>
        <div class="ipdt ipdb">
            <div class="ibgwhite iflex iflexcenter" @click="openLogin">
                <div class="ipdall">
                    <div style="width:48px;height:48px;border-radius:50%;background:#EEE;"></div>
                </div>
                <div><strong>登陆 / 注册</strong></div>
            </div>
        </div>
        <div class="cube-form_groups">
            <div class="ibgwhite">
                <div class="iflex iflexcenter ipdall" @click="goMyinfo">
                    <div class="ipdr mini">
                        <i class="cubeic-person" style="color:#7d2525"></i>
                    </div>
                    <div class="iflexitem">
                        我的资料
                    </div>
                    <i class="cubeic-arrow"></i>
                </div>
                <div class="idiver"></div>
                <div class="iflex iflexcenter ipdall" @click="goMyhistory">
                    <div class="ipdr mini">
                        <i class="cubeic-safe-pay" style="color:#7d2525"></i>
                    </div>
                    <div class="iflexitem">
                        申请记录
                    </div>
                    <i class="cubeic-arrow"></i>
                </div>
                <div class="idiver"></div>
                <div class="iflex iflexcenter ipdall" @click="goRepay">
                    <div class="ipdr mini">
                        <i class="cubeic-tag" style="color:#7d2525"></i>
                    </div>
                    <div class="iflexitem">
                        还款记录
                    </div> <i class="cubeic-arrow"></i>
                </div>
                <div class="idiver"></div>
                <div class="iflex iflexcenter ipdall" @click="goCommed">
                    <div class="ipdr mini">
                        <i class="cubeic-share" style="color:#7d2525"></i>
                    </div>
                    <div class="iflexitem">
                        我的推荐
                    </div> <i class="cubeic-arrow"></i>
                </div>
                <div class="idiver"></div>
                <div class="iflex iflexcenter ipdall" @click="goService">
                    <div class="ipdr mini">
                        <i class="cubeic-info" style="color:#7d2525"></i>
                    </div>
                    <div class="iflexitem">
                        客服与帮助
                    </div> <i class="cubeic-arrow"></i>
                </div>
                <div class="idiver"></div>
                <div class="iflex iflexcenter ipdall" @click="goAbout">
                    <div class="ipdr mini">
                        <i class="cubeic-home" style="color:#58ffd2"></i>
                    </div>
                    <div class="iflexitem">
                        关于我们
                    </div> <i class="cubeic-arrow"></i>
                </div>
            </div>
            <div class="ipdall itxtcenter ifontxs">
                本平台不向学生提供贷款服务
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        methods: {
            goMyinfo() {
                this.$router.push("/account/info")
            },
            goMyhistory() {
                this.$router.push("/account/history")
            },
            openLogin() {
                this.$root.$children[0].login()
            },
            goService(){
                this.$router.push("/account/service")
            },
            goRepay(){
                this.$router.push("/account/repay")
            },
            goCommed(){
                this.$router.push("/account/recommed")
            },
            goAbout(){
                 this.$router.push("/account/about")
            }
        }
    }
</script>

<style>

</style>
