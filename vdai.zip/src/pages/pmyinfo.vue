<template>
    <ipage>
        <iheader slot="header" title="我的资料" />
        <div>
            <div class="itxtcenter ifontxs ipdall">
                花三分钟时间完成资料填写，即可申请借款哦!
            </div>
            <div class="cube-form_groups">
                <div class="ibgwhite">
                    <div class="iflex">
                        <div class="iflex iflexcenter ipdall" @click="goCard">
                            <div class="ipdr mini">
                                <i class="cubeic-share" style="color:#7d2525"></i>
                            </div>
                            <div class="iflexitem">
                                身份信息
                            </div>
                            <i class="cubeic-arrow"></i>
                        </div>
                    </div>
                    <div class="idiver"></div>
                    <div class="iflex">
                        <div class="iflex iflexcenter ipdall" @click="goPerson">
                            <div class="ipdr mini">
                                <i class="cubeic-share"></i>
                            </div>
                            <div class="iflexitem">
                                资料信息
                            </div>
                            <i class="cubeic-arrow"></i>
                        </div>
                    </div>
                    <div class="idiver"></div>
                    <div class="iflex">
                        <div class="iflex iflexcenter ipdall" @click="goBank">
                            <div class="ipdr mini">
                                <i class="cubeic-share"></i>
                            </div>
                            <div class="iflexitem">
                                收款银行卡
                            </div>
                            <i class="cubeic-arrow"></i>
                        </div>
                    </div>
                    <div class="idiver"></div>
                    <div class="iflex">
                        <div class="iflex iflexcenter ipdall" @click="goPhone">
                            <div class="ipdr mini">
                                <i class="cubeic-share"></i>
                            </div>
                            <div class="iflexitem">
                                手机号认证
                            </div>
                            <i class="cubeic-arrow"></i>
                        </div>
                    </div>
                   
                </div>
            </div>
            <div class="ipdall">
                <cube-button>立即借款</cube-button>
            </div>
            <div class="ipdall itxtcenter ifontxs">
                本平台不向学生提供贷款服务
            </div>
        </div>
    </ipage>
</template>

<script>
    export default {
        methods: {
            goCard() {
                this.$router.push("/account/info/card")
            },
            goPerson() {
                this.$router.push("/account/info/person")
            },
            goBank() {
                this.$router.push("/account/info/bank")
            },
            goPhone() {
                this.$router.push("/account/info/phone")
            }
        }
    }
</script>

<style>

</style>
