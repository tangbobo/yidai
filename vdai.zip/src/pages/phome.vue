<template>
  <ipage>
    <iheader slot="header" title="容易贷" hideback />
    <porder v-show="selectedLabelDefault=='首页'" />
    <paccount v-show="selectedLabelDefault=='我的'" />
    <div slot="footer" class="ibgwhite">
      <div class="idiver"></div>
      <cube-tab-bar v-model="selectedLabelDefault" :data="tabs" />
    </div>
  </ipage>
</template>

<script>
  import porder from './porder.vue'
  import paccount from './paccount.vue'
  export default {
    components: {
      porder,
      paccount
    },
    data() {
      return {
        selectedLabelDefault: '首页',
        tabs: [{
          label: '首页',
          icon: 'cubeic-home'
        }, {
          label: '我的',
          icon: 'cubeic-like'
        }],
      };
    },
    methods: {
    }
  };
</script>

<style>

</style>
