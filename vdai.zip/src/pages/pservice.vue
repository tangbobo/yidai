<template>
    <ipage>
        <iheader slot="header" title="在线客服" />
        <div class="ipdl ipdr">
            <div class="ipdall">
                <div class="timeline">2018.08.01</div>
            </div>
            <div class="msgbox">
                <div class="ifontxs ipdb mini">
                    10:01
                </div>
                <div class="iflex">
                    <div class="system">
                        系统
                    </div>
                    <div class="iflexitem"></div>
                </div>
            </div>
            <div class="msgbox">
                <div class="iflex">
                    <div class="iflexitem"></div>
                    <div class="customer">
                        客户
                    </div>
                </div>
                <div class="ifontxs itxtright ipdt mini">
                    10:31
                </div>
            </div>
            <div class="ipdall">
                <div class="timeline">2018.08.01</div>
            </div>
            <div class="msgbox">
                <div class="iflex">
                    <div class="iflexitem"></div>
                    <div class="customer">
                        wo dinggegeni
                    </div>
                </div>
                <div class="ifontxs itxtright ipdt mini">
                    12:31
                </div>
            </div>
        </div>
        <div slot="footer">
            <div class="iflex iflexcenter ibgwhite" style="background:#FAFAFA">
                <div class="iflexitem ipdl ipdr mini">
                    <cube-input v-model="msg" placeholder="请输入您想咨询的问题"></cube-input>
                </div>
                <div>
                    <cube-button @click="send">发送</cube-button>
                </div>
            </div>
        </div>
    </ipage>
</template>

<script>
    export default {
        data() {
            return {
                msg: ""
            }
        },
        methods: {
            send() {}
        }
    }
</script>

<style>
    .msgbox {
        padding-top: 10px;
    }
    .timeline {
        width: 80px;
        text-align: center;
        display: block;
        padding: 6px;
        margin: 0 auto;
        font-size: 12px;
        background: #E0E0E0;
        border-radius: 20px;
        color: #FFF
    }
    .system,
    .customer {
        padding: 15px;
        background: #FC9153;
        color: #FFF;
        font-size: 14px;
        border-radius: 0 14px 14px 14px;
    }
    .customer {
        background: #FFF;
        color: #4A4C5B;
        border-radius: 14px 14px 0 14px;
    }
</style>
