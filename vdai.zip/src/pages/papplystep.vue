<template>
    <ipage>
        <iheader slot="header" title="借款详情" />
        <div>
            <div class="cube-form_groups">
                <div class="ipdall ibgblue itxtcenter">
                    <div class="ipdt ipdb mini" style="font-size:12px">借款金额</div>
                    <div class="ipdb ifontbiger">9000.00</div>
                </div>
                <div class="ibgwhite ipdall">
                    <div class="iflex itxtcenter ipdt ipdb">
                        <div class="iflexitem">
                            <div class="stepparent first done">
                                <div class="step"></div>
                            </div>
                            <div class="ipdt ipdb mini">借款申请</div>
                            <div class="ifontxs">2018.08.07</div>
                            <div class="ifontxs">16:14</div>
                        </div>
                        <div class="iflexitem">
                            <div class="stepparent fail">
                                <div class="step"></div>
                            </div>
                            <div class="ipdt ipdb mini">审核中</div>
                            <div class="ifontxs">2018.08.07</div>
                            <div class="ifontxs">16:14</div>
                        </div>
                        <div class="iflexitem">
                            <div class="stepparent last wait">
                                <div class="step"></div>
                            </div>
                            <div class="ipdt ipdb mini">放款成功</div>
                            <!-- <div class="ifontxs">2018.08.07</div>
                                                                <div class="ifontxs ipdt mini">16:14</div> -->
                        </div>
                    </div>
                </div>
                <div class="cube-form_groups">
                    <p class="cube-form-group-legend">借款详情：</p>
                    <div class="cube-form_groups">
                        <div class="ibgwhite">
                            <div class="iflex iflexcenter">
                                <div class="iflexitem ipdall ifontxs">
                                    借款金额：
                                </div>
                                <div class="ipdall">
                                    ￥5000.00
                                </div>
                            </div>
                            <div class="idiver"></div>
                            <div class="iflex iflexcenter">
                                <div class="iflexitem ipdall ifontxs">
                                    借款期限：
                                </div>
                                <div class="ipdall">
                                    三个月
                                </div>
                            </div>
                            <div class="idiver"></div>
                            <div class="iflex iflexcenter">
                                <div class="iflexitem ipdall ifontxs">
                                    每月还款：
                                </div>
                                <div class="ipdall">
                                    ￥2000.00
                                </div>
                            </div>
                            <div class="idiver"></div>
                            <div class="iflex iflexcenter">
                                <div class="iflexitem ipdall ifontxs">
                                    借款利率：
                                </div>
                                <div class="ipdall">
                                    月利率 7%
                                </div>
                            </div>
                            <div class="idiver"></div>
                            <div class="iflex iflexcenter">
                                <div class="iflexitem ipdall ifontxs">
                                    到账银行：
                                </div>
                                <div class="ipdall itxtright">
                                    <div>中国银行</div>
                                    <div class="ifontxs ipdt mini">62284805568458754997</div>
                                </div>
                            </div>
                            <div class="idiver"></div>
                            <div class="iflex iflexcenter">
                                <div class="iflexitem ipdall ifontxs">
                                    审核费用：
                                </div>
                                <div class="ipdall">
                                    ￥38.00
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="ipdall itxtcenter ifontxs">
                本平台不向学生提供贷款服务
            </div>
        </div>
    </ipage>
</template>

<script>
    export default {
        data() {
            return {}
        },
        methods: {
            goApply() {
                this.$router.go(-2)
            }
        }
    }
</script>

<style scoped>
    .stepparent {
        position: relative;
        z-index: 1;
    }
    .stepparent::before,
    .stepparent::after {
        position: absolute;
        content: "";
        left: 50%;
        right: 0;
        top: 50%;
        height: 2px;
        background: #E0E0E0;
        z-index: -1;
        margin-top: -1px;
    }
    .stepparent::after {
        left: 0;
        right: 50%;
        background: #E8864C;
    }
    .stepparent.first::after,
    .stepparent.last::before {
        display: none;
    }
    .stepparent .step {
        display: block;
        margin: 0 auto;
        line-height: 20px;
        font-size: 12px;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        text-align: center;
        background: #E0E0E0
    }
    .stepparent.done .step,
    .stepparent.done::after,
    .stepparent.done::before {
        background: #E8864C
    }
    .stepparent.wait .step,
    .stepparent.wait::before,
    .stepparent.wait::after {
        background: #E0E0E0
    }
    .stepparent.fail .step {
        background: #E8864C
    }
</style>
