<template>
    <ipage>
        <iheader slot="header" title="银行卡" />
        <div class="ipdall mini">
            <div class="ipdall mini">
                <div class="icard">
                    <div class="iflex iflexcenter">
                        <div class="iflexitem">中国银行</div>
                        <div class="ifontxs">
                            默认银行卡
                        </div>
                    </div>
                    <div class="ipdt">
                        283398 **** **** **** 27348
                    </div>
                </div>
            </div>
            <div class="ipdall mini">
                <div class="icard">
                    <div class="iflex iflexcenter">
                        <div class="iflexitem">中国银行</div>
                        <div class="ifontxs">
                        
                        </div>
                    </div>
                    <div class="ipdt">
                        283398 **** **** **** 27348
                    </div>
                </div>
            </div>
            <div class="ipdall mini">
                <div class="icard">
                    <div class="iflex iflexcenter">
                        <div class="iflexitem">中国银行</div>
                        <div class="ifontxs">
                          
                        </div>
                    </div>
                    <div class="ipdt">
                        283398 **** **** **** 27348
                    </div>
                </div>
            </div>
        </div>
    </ipage>
</template>

<script>
    export default {}
</script>

<style scoped>
    .icard {
        background: #FFF;
        border-radius: 4px;
        padding: 16px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.08)
    }
</style>
