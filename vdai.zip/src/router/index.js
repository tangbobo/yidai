import Vue from 'vue'
import Router from 'vue-router'


import Home from '@/pages/phome'
import Apply from '@/pages/papply'
import ApplyStep from '@/pages/papplystep'
import Myinfo from '@/pages/pmyinfo'

import MyHistory from '@/pages/phistory'

import MyinfoCard from '@/pages/pinfocard'
import MyinfoBank from '@/pages/pinfobank'
import MyinfoPerson from '@/pages/pinfoperson'
import MyinfoPhone from '@/pages/pinfophone'

import Service from '@/pages/pservice'
import Repay from '@/pages/prepay'
import ReCommed from '@/pages/precommed'
import About from '@/pages/pabout'





Vue.use(Router)

export default new Router({
  routes: [{
      path: '/',
      name: 'Home',
      component: Home
    },{
      path: '/account/apply/:much/:long',
      name: 'Apply',
      component: Apply
    },{
      path: '/account/info',
      name: 'MyInfo',
      component: Myinfo
    },{
      path: '/account/history',
      name: 'MyHistory',
      component: MyHistory
    },{
      path: '/account/repay',
      name: 'Repay',
      component: Repay
    },{
      path: '/account/service',
      name: 'Service',
      component: Service
    },{
      path: '/account/about',
      name: 'About',
      component: About
    },{
      path: '/account/recommed',
      name: 'ReCommed',
      component: ReCommed
    },{
      path: '/account/info/card',
      name: 'MyinfoCard',
      component: MyinfoCard
    },{
      path: '/account/info/person',
      name: 'MyinfoPerson',
      component: MyinfoPerson
    },{
      path: '/account/info/bank',
      name: 'MyinfoBank',
      component: MyinfoBank
    },{
      path: '/account/info/phone',
      name: 'MyinfoPhone',
      component: MyinfoPhone
    },{
      path: '/account/apply/confirm/step/detail',
      name: 'ApplyStep',
      component: ApplyStep
    }]
})
